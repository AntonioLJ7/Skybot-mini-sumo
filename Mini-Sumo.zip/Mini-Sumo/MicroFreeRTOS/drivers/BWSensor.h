/*
 * motor.h
 *
 *  Created on: 22 oct. 2022
 *      Author: anton
 */

#ifndef DRIVERS_BWSENSOR_H_
#define DRIVERS_BWSENSOR_H_

#include<stdint.h>
#include "FreeRTOS.h"
#include "event_groups.h"

extern void ConfiguraBWSensores(void);
extern void Mover_Microbot(int c);
extern void Girar_Microbot(int g);
extern void GPIOAIntHandler(void);
extern void Parar_Microbot(void);

extern EventGroupHandle_t FlagsEventos;
#define ENSD 0X0001
#define ENSI 0X0002
#define ENSA 0X0004

extern uint16_t countDer;
extern uint16_t countIzq;

#endif /* DRIVERS_BWSENSOR_H_ */
