/*
 * motor.c
 *
 *  Created on: 22 oct. 2022
 *      Author: anton
 */
#include <drivers/ServoMotor.h>
#include <drivers/ServoMotor.h>
#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_memmap.h"
#include "driverlib/sysctl.h"
#include "driverlib/pwm.h"
#include "driverlib/pin_map.h"
#include "driverlib/interrupt.h"
#include "drivers/buttons.h"
#include "driverlib/gpio.h"
#include "inc/hw_ints.h"
#include "task.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "semphr.h"
#include "queue.h"


#define PERIOD_PWM 1250 // TODO Ciclos de reloj para conseguir una se�al peri�dica de 50Hz (seg�n reloj de perif�rico usado)
#define COUNT_1MS 62   // TODO: Ciclos para amplitud de pulso de 1ms (max velocidad en un sentido)
#define STOPCOUNT 94  // TODO: Ciclos para amplitud de pulso de parada (1.52ms)
#define COUNT_2MS 125   // TODO: Ciclos para amplitud de pulso de 2ms (max velocidad en el otro sentido)
#define NUM_STEPS 63    // Pasos para cambiar entre el pulso de 2ms al de 1ms
#define CYCLE_INCREMENTS (abs(COUNT_1MS-COUNT_2MS))/NUM_STEPS  // Variacion de amplitud tras pulsacion

#define PARADO 0
#define AVANZAR 1
#define RETROCEDE 2
#define GIRO_IZQUIERDA 3
#define GIRO_DERECHA 4
#define ROTAR 5

xSemaphoreHandle Mutexmotores;

uint16_t cicloD,cicloI;

void ConfiguraMotores(void)
{

    SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM1);  //Habilita modulo PWM
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF); // Habilita puerto F salida para se�al PWM1

    GPIOPinTypePWM(GPIO_PORTF_BASE, GPIO_PIN_2);    // PF2 como salida PWM
    GPIOPinConfigure(GPIO_PF2_M1PWM6 );             // del m�dulo PWM1

    GPIOPinTypePWM(GPIO_PORTF_BASE, GPIO_PIN_3);    // PF3 como salida PWM
    GPIOPinConfigure(GPIO_PF3_M1PWM7);              // del m�dulo PWM1

    PWMGenConfigure(PWM1_BASE, PWM_GEN_3, PWM_GEN_MODE_UP_DOWN);   // M�dulo PWM contara hacia abajo
    PWMGenPeriodSet(PWM1_BASE, PWM_GEN_3, PERIOD_PWM-1);    // Carga la cuenta que establece la frecuencia de la se�al PWM

    PWMOutputState(PWM1_BASE, PWM_OUT_6_BIT, true); // Habilita la salida de la se�al 6 del PWM1
    PWMOutputState(PWM1_BASE, PWM_OUT_7_BIT, true); // Habilita la salida de la se�al 7 del PWM1

    VelocidadRuedas(STOPCOUNT,STOPCOUNT);

    PWMGenEnable(PWM1_BASE, PWM_GEN_3); // Habilita/pone en marcha el generador 3 del PWM1

    Mutexmotores=xSemaphoreCreateMutex();

}

void VelocidadRuedas(uint16_t cicloD, uint16_t cicloI)
{
    PWMPulseWidthSet(PWM1_BASE, PWM_OUT_6, cicloD);
    PWMPulseWidthSet(PWM1_BASE, PWM_OUT_7, cicloI);
}

void Movimiento(int movimiento){

    xSemaphoreTake(Mutexmotores,portMAX_DELAY);

    switch(movimiento){

        case PARADO:

            cicloD = STOPCOUNT;
            cicloI = STOPCOUNT;
            VelocidadRuedas(cicloD,cicloI);
            break;

        case AVANZAR:

            cicloD = COUNT_2MS;
            cicloI = COUNT_1MS;
            VelocidadRuedas(cicloD,cicloI);
            break;

        case RETROCEDE:

            cicloD = COUNT_1MS;
            cicloI = COUNT_2MS;
            VelocidadRuedas(cicloD,cicloI);
            break;

        case GIRO_IZQUIERDA:

            cicloD = COUNT_1MS;
            cicloI = COUNT_1MS+20;
            VelocidadRuedas(cicloD,cicloI);
            break;

        case GIRO_DERECHA:

            cicloD = COUNT_2MS;
            cicloI = COUNT_2MS-20;
            VelocidadRuedas(cicloD,cicloI);
            break;

        case ROTAR:

            cicloD = COUNT_2MS;
            cicloI = COUNT_2MS;
            VelocidadRuedas(cicloD,cicloI);

            break;
        default:

            cicloD = STOPCOUNT;
            cicloI = STOPCOUNT;
            VelocidadRuedas(cicloD,cicloI);
            break;

    }

    xSemaphoreGive(Mutexmotores);
}
