/*
 * motor.h
 *
 *  Created on: 22 oct. 2022
 *      Author: anton
 */

#ifndef DRIVERS_SERVOMOTOR_H_
#define DRIVERS_SERVOMOTOR_H_

#include<stdint.h>
#include "FreeRTOS.h"
#include "semphr.h"

BaseType_t crear_tarea_servoMotor(uint16_t stack_size,uint8_t prioriry );

#define PARADO 0
#define AVANZAR 1
#define RETROCEDE 2
#define GIRO_IZQUIERDA 3
#define GIRO_DERECHA 4

extern void ConfiguraMotores(void);
extern void VelocidadRuedas(uint16_t cicloI, uint16_t cicloD);
extern void Movimiento(int movimiento);

extern uint16_t cicloDer;
extern uint16_t cicloIzq;

#endif /* DRIVERS_SERVOMOTOR_H_ */
