#include<stdint.h>
#include<stdbool.h>

#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "inc/hw_ints.h"
#include "inc/hw_adc.h"
#include "driverlib/gpio.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/sysctl.h"
#include "driverlib/interrupt.h"
#include "driverlib/adc.h"
#include "driverlib/timer.h"
#include "configADC.h"
#include "task.h"
#include "queue.h"
#include <drivers/ServoMotor.h>
#include <drivers/BWSensor.h>

QueueHandle_t cola_adc;

//Provoca el disparo de una conversion (hemos configurado el ADC con "disparo software" (Processor trigger)
void configADC_DisparaADC(void)
{

    ADCProcessorTrigger(ADC0_BASE,0);
}

void configADC_IniciaADC(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC0);
     SysCtlPeripheralSleepEnable(SYSCTL_PERIPH_ADC0);

     //HABILITAMOS EL GPIOD
     SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD);
     SysCtlPeripheralSleepEnable(SYSCTL_PERIPH_GPIOD);
     // Enable pin PD3 for ADC AIN4
     GPIOPinTypeADC(GPIO_PORTD_BASE, GPIO_PIN_3);

     //CONFIGURAR SECUENCIADOR 0
     ADCSequenceDisable(ADC0_BASE,0);

     //Configuramos la velocidad de conversion al maximo (1MS/s)
     ADCClockConfigSet(ADC0_BASE, ADC_CLOCK_RATE_FULL, 1);

     ADCSequenceConfigure(ADC0_BASE,0,ADC_TRIGGER_PROCESSOR,0);  //Disparo software (processor trigger)
     ADCSequenceStepConfigure(ADC0_BASE,0,0,ADC_CTL_CH4);
     ADCSequenceStepConfigure(ADC0_BASE,0,1,ADC_CTL_CH4);
     ADCSequenceStepConfigure(ADC0_BASE,0,2,ADC_CTL_CH4);
     ADCSequenceStepConfigure(ADC0_BASE,0,3,ADC_CTL_CH4);
     ADCSequenceStepConfigure(ADC0_BASE,0,4,ADC_CTL_CH4);
     ADCSequenceStepConfigure(ADC0_BASE,0,5,ADC_CTL_CH4|ADC_CTL_IE |ADC_CTL_END );   //La ultima muestra provoca la interrupcion
     ADCSequenceEnable(ADC0_BASE,0); //ACTIVO LA SECUENCIA

     //Habilita las interrupciones
     ADCIntClear(ADC0_BASE,0);
     ADCIntEnable(ADC0_BASE,0);
     IntPrioritySet(INT_ADC0SS0,configMAX_SYSCALL_INTERRUPT_PRIORITY);
     //configMAX_SYSCALL_INTERRUPT_PRIORITY
     IntEnable(INT_ADC0SS0);

     cola_adc=xQueueCreate(10,sizeof(uint16_t));
     if (cola_adc==NULL)
     {
         while(1);
     }
}

void configADC_LeeADC(uint16_t *datos)
{
    xQueueReceive(cola_adc,datos,portMAX_DELAY);
}


int binary_lookup(int *Arr, int key, int imin, int imax)
{
  int imid;

  while (imin < imax)
    {
      imid= (imin+imax)>>1;

      if (Arr[imid] < key)
        imin = imid + 1;
      else
        imax = imid;
    }
    return imax;    //Al final imax=imin y en dicha posicion hay un numero mayor o igual que el buscado
}

void configADC0_ISR(void)
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;

    MuestrasLeidasADC leidasCont;
    MuestrasADC finalesCont;
    uint16_t media;


    ADCIntClear(ADC0_BASE,0);//LIMPIAMOS EL FLAG DE INTERRUPCIONES
    ADCSequenceDataGet(ADC0_BASE,0,(uint32_t *)&leidasCont);//COGEMOS LOS DATOS GUARDADOS

    //Pasamos de 32 bits a 16 (el conversor es de 12 bits, as� que s�lo son significativos los bits del 0 al 11)
    finalesCont.chan1=leidasCont.chan1;
    finalesCont.chan2=leidasCont.chan2;
    finalesCont.chan3=leidasCont.chan3;
    finalesCont.chan4=leidasCont.chan4;
    finalesCont.chan5=leidasCont.chan5;
    finalesCont.chan6=leidasCont.chan6;

    media=(finalesCont.chan1+finalesCont.chan2+finalesCont.chan3+finalesCont.chan4+finalesCont.chan5+finalesCont.chan6)/6;

    xQueueSendFromISR(cola_adc,&media,&xHigherPriorityTaskWoken);

    portEND_SWITCHING_ISR(xHigherPriorityTaskWoken);
}

