/*
 * motor.c
 *
 *  Created on: 22 oct. 2022
 *      Author: Julia
 */
#include <drivers/BWSensor.h>
#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_memmap.h"
#include "driverlib/sysctl.h"
#include "driverlib/pwm.h"
#include "driverlib/pin_map.h"
#include "driverlib/interrupt.h"
#include "drivers/buttons.h"
#include "driverlib/gpio.h"
#include "inc/hw_ints.h"
#include "task.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "event_groups.h"
#include "semphr.h"
#include "queue.h"
#include "timers.h"
#include "drivers/ServoMotor.h"

#define PARADO 0
#define AVANZAR 1
#define RETROCEDE 2
#define GIRO_IZQUIERDA 3
#define GIRO_DERECHA 4

#define SENSORTASKSTACKSIZE 128
#define RADIUS 3
#define NUMSTRIPS 18
double PI = 3.14159265358979323846;

EventGroupHandle_t FlagsEventos;

#define ENSD 0X0001
#define ENSI 0X0002
#define ENSA 0X0004

uint8_t RightPrev=0;
uint8_t LeftPrev=0;

uint16_t countDer=0;
uint16_t countIzq=0;

void ConfiguraBWSensores(void)
{

    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
    GPIOPinTypeGPIOInput(GPIO_PORTA_BASE,GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_7);
    GPIOIntTypeSet(GPIO_PORTA_BASE,GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_7,GPIO_BOTH_EDGES);
    GPIOIntClear(GPIO_PORTA_BASE,GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_7);
    GPIOIntEnable(GPIO_PORTA_BASE,GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_7);
    IntPrioritySet(INT_GPIOA,configMAX_SYSCALL_INTERRUPT_PRIORITY);
    IntEnable(INT_GPIOA);

    FlagsEventos = xEventGroupCreate();
    if( FlagsEventos == NULL )
    {
        while(1);
    }

}

void GPIOAIntHandler(void)
{
    //GPIOIntClear(GPIO_PORTA_BASE,GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_7);  //limpiamos flags
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;

    if(GPIOIntStatus(GPIO_PORTA_BASE,GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_7) & GPIO_PIN_2)//para ver que puerto es
        {
            if(GPIOPinRead(GPIO_PORTA_BASE,GPIO_PIN_2) & GPIO_PIN_2)
            {
                xEventGroupSetBitsFromISR(FlagsEventos,ENSI,&xHigherPriorityTaskWoken);
            }
        }
        else if(GPIOIntStatus(GPIO_PORTA_BASE,GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_7) & GPIO_PIN_3)
        {
            if(GPIOPinRead(GPIO_PORTA_BASE,GPIO_PIN_3) & GPIO_PIN_3)
            {
                xEventGroupSetBitsFromISR(FlagsEventos,ENSD,&xHigherPriorityTaskWoken);
            }
        }
        else if(GPIOIntStatus(GPIO_PORTA_BASE,GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_7) & GPIO_PIN_7)
        {
            if(GPIOPinRead(GPIO_PORTA_BASE,GPIO_PIN_7) & GPIO_PIN_7)
            {
                xEventGroupSetBitsFromISR(FlagsEventos,ENSA,&xHigherPriorityTaskWoken);
            }
        }


    GPIOIntClear(GPIO_PORTA_BASE,GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_7);

    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);

}


void Mover_Microbot(int c){

    countDer=0;
    countIzq=0;

    if (c>0){ //si nos dan centimetros positivos ponemos las ruedas a andar en un sentido
        Movimiento(AVANZAR);
    }
    else{ // Si son negativos lo ponemos a andar en el sentido contrario
        Movimiento(RETROCEDE);
    }

    //Calculamos el numero de lineas a contar con el factor de correccion corr por los rebotes
    int lines = abs(c)*(1/(2*PI*RADIUS))*NUMSTRIPS;
    // Si alguno de los dos contadores alcanza el numero de lineas paramos el movimiento
    while((countDer<=lines)&&(countIzq<=lines));

    //Paramos el movimiento
    Movimiento(PARADO);
    //Reseteamos los contadores
}

void Girar_Microbot(int g){

    countDer=0;
    countIzq=0;

    if (g>0){//si nos dan grados positivos ponemos las ruedas a girar en un sentido
        Movimiento(GIRO_DERECHA);
    }
    else{// Si son negativos lo ponemos a girar en el sentido contrario
        Movimiento(GIRO_IZQUIERDA);
        return;
    }
    //Calculamos el numero de lineas a contar con el factor de correccion corr por los rebotes
    int lines = g*NUMSTRIPS/360;
    // Si alguno de los dos contadores alcanza el numero de lineas paramos el giro
    while((countDer<=lines)&&(countIzq<=lines));
    //Paramos el giro
    Movimiento(PARADO);
    //Reseteamos los contadores
}


